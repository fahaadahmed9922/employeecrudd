# /models/attendance_model.py

from datetime import date, datetime

class AttendanceModel:
    def __init__(self, mysql):
        self.mysql = mysql

    def mark_attendance(self, emp_id):
        today = date.today()
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT id, sign_in, sign_out FROM attendance WHERE employee_id=%s AND date=%s", (emp_id, today))
        record = cur.fetchone()

        if record:
            if record[2] is None:
                sign_out_time = datetime.now().strftime('%H:%M:%S')
                cur.execute("UPDATE attendance SET sign_out=%s WHERE id=%s", (sign_out_time, record[0]))
                self.mysql.connection.commit()
                cur.close()
                return {'status': 'success', 'message': f'Sign Out recorded at {sign_out_time}'}
            else:
                cur.close()
                return {'status': 'info', 'message': 'Already signed out today.'}
        else:
            sign_in_time = datetime.now().strftime('%H:%M:%S')
            cur.execute("INSERT INTO attendance (employee_id, date, sign_in) VALUES (%s, %s, %s)",
                        (emp_id, today, sign_in_time))
            self.mysql.connection.commit()
            cur.close()
            return {'status': 'success', 'message': f'Sign In recorded at {sign_in_time}'}

    def get_today_summary(self):
        today = date.today()
        cur = self.mysql.connection.cursor()

        cur.execute("SELECT COUNT(DISTINCT employee_id) FROM attendance WHERE DATE(date) = %s", (today,))
        total_present = cur.fetchone()[0] or 0

        cur.execute("SELECT COUNT(*) FROM employees")
        total_employees = cur.fetchone()[0] or 0

        total_absent = max(total_employees - total_present, 0)

        cur.execute("""
            SELECT e.name, DATE(a.date), a.sign_in, a.sign_out
            FROM attendance a
            JOIN employees e ON a.employee_id = e.id
            WHERE DATE(a.date) = %s
            ORDER BY a.date DESC
        """, (today,))
        records = cur.fetchall()
        cur.close()

        return {
            'total_present': total_present,
            'total_absent': total_absent,
            'total_employees': total_employees,
            'records': records
        }
