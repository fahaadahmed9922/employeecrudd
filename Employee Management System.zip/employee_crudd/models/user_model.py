# /models/user_model.py

class UserModel:
    def __init__(self, mysql):
        self.mysql = mysql

    def authenticate(self, username, password):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE username=%s AND password=%s", (username, password))
        user = cur.fetchone()
        cur.close()
        return user
