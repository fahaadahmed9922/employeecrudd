# /models/employee_model.py

from werkzeug.utils import secure_filename
import os
import qrcode

class EmployeeModel:
    def __init__(self, mysql, upload_folder, qrcode_folder):
        self.mysql = mysql
        self.upload_folder = upload_folder
        self.qrcode_folder = qrcode_folder

    def get_all_employees(self):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT id, name, username, email, password, city, photo FROM employees")
        employees = cur.fetchall()
        cur.close()
        return employees

    def get_employee(self, emp_id):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT id, name, username, email, password, city, photo FROM employees WHERE id=%s", (emp_id,))
        emp = cur.fetchone()
        cur.close()
        return emp

    def add_employee(self, name, username, email, password, city, photo_file):
        photo_filename = ''
        if photo_file and photo_file.filename != '':
            photo_filename = secure_filename(photo_file.filename)
            photo_file.save(os.path.join(self.upload_folder, photo_filename))

        cur = self.mysql.connection.cursor()
        cur.execute("""
            INSERT INTO employees (name, username, email, password, city, photo)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (name, username, email, password, city, photo_filename))
        self.mysql.connection.commit()
        emp_id = cur.lastrowid

        safe_name = secure_filename(name.lower().replace(" ", "_"))
        qr_filename = f"{safe_name}_{emp_id}.png"
        qr_path = os.path.join(self.qrcode_folder, qr_filename)
        qr = qrcode.make(str(emp_id))
        qr.save(qr_path)

        cur.close()
        return emp_id

    def update_employee(self, emp_id, name, username, email, password, city, photo_file):
        cur = self.mysql.connection.cursor()
        if photo_file and photo_file.filename != '':
            photo_filename = secure_filename(photo_file.filename)
            photo_file.save(os.path.join(self.upload_folder, photo_filename))
            cur.execute("""
                UPDATE employees
                SET name=%s, username=%s, email=%s, password=%s, city=%s, photo=%s
                WHERE id=%s
            """, (name, username, email, password, city, photo_filename, emp_id))
        else:
            cur.execute("""
                UPDATE employees
                SET name=%s, username=%s, email=%s, password=%s, city=%s
                WHERE id=%s
            """, (name, username, email, password, city, emp_id))
        self.mysql.connection.commit()
        cur.close()

    def delete_employee(self, emp_id):
        cur = self.mysql.connection.cursor()
        cur.execute("DELETE FROM employees WHERE id=%s", (emp_id,))
        self.mysql.connection.commit()
        cur.close()

    def get_employee_count(self):
     cur = self.mysql.connection.cursor()
     cur.execute("SELECT COUNT(*) FROM employees")
     count = cur.fetchone()[0]
     cur.close()
     return count

    def get_gender_count(self):
     cur = self.mysql.connection.cursor()
     cur.execute("SELECT COUNT(*) FROM employees WHERE gender='Male'")
     male = cur.fetchone()[0]
     cur.execute("SELECT COUNT(*) FROM employees WHERE gender='Female'")
     female = cur.fetchone()[0]
     cur.close()
     return male, female