# /models/attendance_model.py

from datetime import date, datetime

class AttendanceModel:
    def __init__(self, mysql):
        self.mysql = mysql

    def mark_attendance(self, emp_id, photo_filename=None):
      today = date.today()
      cur = self.mysql.connection.cursor()
      cur.execute("SELECT id, sign_in, sign_out FROM attendance WHERE employee_id=%s AND date=%s", (emp_id, today))
      record = cur.fetchone()

      if record:
        if record[2] is None:
            sign_out_time = datetime.now().strftime('%H:%M:%S')
            cur.execute("UPDATE attendance SET sign_out=%s WHERE id=%s", (sign_out_time, record[0]))
            self.mysql.connection.commit()
            cur.close()
            return {'status': 'success', 'message': f'Sign Out recorded at {sign_out_time}'}
        else:
            cur.close()
            return {'status': 'info', 'message': 'Already signed out today.'}
      else:
        sign_in_time = datetime.now().strftime('%H:%M:%S')
        if photo_filename:
            cur.execute("INSERT INTO attendance (employee_id, date, sign_in, photo) VALUES (%s, %s, %s, %s)",
                        (emp_id, today, sign_in_time, photo_filename))
        else:
            cur.execute("INSERT INTO attendance (employee_id, date, sign_in) VALUES (%s, %s, %s)",
                        (emp_id, today, sign_in_time))
        self.mysql.connection.commit()
        cur.close()
        return {'status': 'success', 'message': f'Sign In recorded at {sign_in_time}'}


    def save_attendance_photo(self, emp_id, photo_filename):
        """
        Saves the captured attendance photo filename for the given employee on today's date.
        Assumes your attendance table has a `photo` column (ALTER TABLE attendance ADD COLUMN photo VARCHAR(255);).
        """
        today = date.today()
        cur = self.mysql.connection.cursor()
        cur.execute(
            "SELECT id FROM attendance WHERE employee_id=%s AND date=%s",
            (emp_id, today)
        )
        record = cur.fetchone()

        if record:
            cur.execute(
                "UPDATE attendance SET photo=%s WHERE id=%s",
                (photo_filename, record[0])
            )
        else:
            sign_in_time = datetime.now().strftime('%H:%M:%S')
            cur.execute(
                "INSERT INTO attendance (employee_id, date, sign_in, photo) VALUES (%s, %s, %s, %s)",
                (emp_id, today, sign_in_time, photo_filename)
            )

        self.mysql.connection.commit()
        cur.close()

    def get_today_summary(self):
        """
        Returns summary of today's attendance including total present, absent, and detailed records.
        """
        today = date.today()
        cur = self.mysql.connection.cursor()

        cur.execute("SELECT COUNT(DISTINCT employee_id) FROM attendance WHERE DATE(date) = %s", (today,))
        total_present = cur.fetchone()[0] or 0

        cur.execute("SELECT COUNT(*) FROM employees")
        total_employees = cur.fetchone()[0] or 0

        total_absent = max(total_employees - total_present, 0)

        cur.execute("""
            SELECT e.name, DATE(a.date), a.sign_in, a.sign_out, a.photo
            FROM attendance a
            JOIN employees e ON a.employee_id = e.id
            WHERE DATE(a.date) = %s
            ORDER BY a.date DESC
        """, (today,))
        records = cur.fetchall()
        cur.close()

        return {
            'total_present': total_present,
            'total_absent': total_absent,
            'total_employees': total_employees,
            'records': records
        }

    def get_attendance_records(self):
        """
        Retrieve all attendance records with joined employee data for exporting reports.
        """
        cur = self.mysql.connection.cursor()
        cur.execute("""
            SELECT a.id, e.name, e.username, e.email, e.city, a.date, a.sign_in, a.sign_out, a.photo
            FROM attendance a
            JOIN employees e ON a.employee_id = e.id
            ORDER BY a.date DESC
        """)
        records = cur.fetchall()
        cur.close()
        return records
