# /routes/employee_routes.py

from flask import (
    Blueprint, render_template, request, redirect, url_for,
    session, flash, send_from_directory, current_app
)
from models.employee_model import EmployeeModel
from models.attendance_model import AttendanceModel
from reports import report_utils

employee_bp = Blueprint('employee', __name__)

def init_employee_routes(app, mysql, upload_folder, qrcode_folder):
    """
    Initialize employee routes with the provided app and dependencies.
    """
    emp_model = EmployeeModel(mysql, upload_folder, qrcode_folder)
    attendance_model = AttendanceModel(mysql)  # ✅ Correctly initialize AttendanceModel

    # =================== Dashboard ===================
    @employee_bp.route('/')
    def dashboard():
        if 'loggedin' not in session:
            return redirect(url_for('auth.login'))
        employees = emp_model.get_all_employees()
        return render_template('index.html', employees=[
            {
                'id': e[0],
                'name': e[1],
                'username': e[2],
                'email': e[3],
                'password': e[4],
                'city': e[5],
                'photo': e[6]
            } for e in employees
        ])

    # =================== Add Employee ===================
    @employee_bp.route('/add', methods=['GET', 'POST'])
    def add_employee():
        if 'loggedin' not in session:
            return redirect(url_for('auth.login'))

        if request.method == 'POST':
            emp_model.add_employee(
                request.form['name'],
                request.form['username'],
                request.form['email'],
                request.form['password'],
                request.form['city'],
                request.files['photo']
            )
            flash("Employee added successfully with QR generated.", "success")
            return redirect(url_for('employee.dashboard'))

        return render_template('add_employee.html')

    # =================== Edit Employee ===================
    @employee_bp.route('/edit/<int:id>', methods=['GET', 'POST'])
    def edit_employee(id):
        if 'loggedin' not in session:
            return redirect(url_for('auth.login'))

        if request.method == 'POST':
            emp_model.update_employee(
                id,
                request.form['name'],
                request.form['username'],
                request.form['email'],
                request.form['password'],
                request.form['city'],
                request.files['photo']
            )
            flash("Employee updated successfully.", "success")
            return redirect(url_for('employee.dashboard'))

        emp = emp_model.get_employee(id)
        return render_template('edit_employee.html', employee=emp)

    # =================== Delete Employee ===================
    @employee_bp.route('/delete/<int:id>')
    def delete_employee(id):
        if 'loggedin' not in session:
            return redirect(url_for('auth.login'))

        emp_model.delete_employee(id)
        flash("Employee deleted successfully.", "success")
        return redirect(url_for('employee.dashboard'))

    # =================== Serve Uploaded Photos ===================
    @employee_bp.route('/uploads/<filename>')
    def uploaded_file(filename):
        uploads_folder = current_app.config['UPLOAD_FOLDER']
        return send_from_directory(uploads_folder, filename)

    # =================== Serve QR Codes ===================
    @employee_bp.route('/qrcodes/<filename>')
    def qrcode_file(filename):
        qrcode_folder = current_app.config['QRCODE_FOLDER']
        return send_from_directory(qrcode_folder, filename)

    # =================== Reports Page ===================
    @employee_bp.route('/reports')
    def reports_page():
        if 'loggedin' not in session:
            return redirect(url_for('auth.login'))
        return render_template('reports.html')

    # =================== Export Employees XLSX ===================
    @employee_bp.route('/export/employees/xlsx')
    def export_employees_xlsx():
        employees = emp_model.get_all_employees()
        employee_list = [
            [e[0], e[1], e[2], e[3], e[5]] for e in employees
        ]
        return report_utils.export_employees_to_excel(employee_list)

    # =================== Export Attendance XLSX ===================
    @employee_bp.route('/export/attendance/xlsx')
    def export_attendance_xlsx():
        attendance_records = attendance_model.get_attendance_records()  # ✅ FIXED: Use attendance_model
        return report_utils.export_attendance_to_excel(attendance_records)

    # =================== Export Employees PDF ===================
    @employee_bp.route('/export/employees/pdf')
    def export_employees_pdf():
        employees = emp_model.get_all_employees()
        employee_list = [
            {'id': e[0], 'name': e[1], 'username': e[2], 'email': e[3], 'city': e[5]}
            for e in employees
        ]
        context = {'employees': employee_list}
        return report_utils.export_to_pdf('employee_report_pdf.html', context, 'employees.pdf')

    # =================== Export Attendance PDF ===================
    @employee_bp.route('/export/attendance/pdf')
    def export_attendance_pdf():
        attendance_records = attendance_model.get_attendance_records()  # ✅ FIXED: Use attendance_model
        context = {'records': attendance_records}
        return report_utils.export_to_pdf('attendance_report_pdf.html', context, 'attendance.pdf')

    # ✅ Register Blueprint
    app.register_blueprint(employee_bp, url_prefix='/')
