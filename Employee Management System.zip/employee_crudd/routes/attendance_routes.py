# /routes/attendance_routes.py

from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for
from models.attendance_model import AttendanceModel

attendance_bp = Blueprint('attendance', __name__)

def init_attendance_routes(app, mysql):
    att_model = AttendanceModel(mysql)

    @attendance_bp.route('/attendance_scan')
    def attendance_scan():
        if 'loggedin' not in session:
            return redirect(url_for('auth.login'))
        return render_template('attendance.html')

    @attendance_bp.route('/mark_attendance', methods=['POST'])
    def mark_attendance():
        data = request.get_json()
        emp_id = data.get('employee_id')
        result = att_model.mark_attendance(emp_id)
        return jsonify(result)

    @attendance_bp.route('/attendance_dashboard')
    def attendance_dashboard():
        if 'loggedin' not in session:
            return redirect(url_for('auth.login'))

        summary = att_model.get_today_summary()
        return render_template('attendance_dashboard.html',
                               total_present=summary['total_present'],
                               total_absent=summary['total_absent'],
                               total_employees=summary['total_employees'],
                               records=summary['records'])

    app.register_blueprint(attendance_bp)
