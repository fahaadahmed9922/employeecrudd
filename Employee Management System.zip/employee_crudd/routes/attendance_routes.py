# /routes/attendance_routes.py

from flask import (
    Blueprint, render_template, request, jsonify, session, redirect, url_for, current_app
)
from models.attendance_model import AttendanceModel
import os
import base64
from datetime import datetime

attendance_bp = Blueprint('attendance', __name__)

def init_attendance_routes(app, mysql):
    att_model = AttendanceModel(mysql)

    @attendance_bp.route('/attendance_scan')
    def attendance_scan():
        if 'loggedin' not in session:
            return redirect(url_for('auth.login'))
        return render_template('attendance.html')

    @attendance_bp.route('/mark_attendance', methods=['POST'])
    def mark_attendance():
        data = request.get_json()
        emp_id = data.get('employee_id')
        result = att_model.mark_attendance(emp_id)
        return jsonify(result)

    @attendance_bp.route('/attendance_dashboard')
    def attendance_dashboard():
        if 'loggedin' not in session:
            return redirect(url_for('auth.login'))

        summary = att_model.get_today_summary()
        return render_template('attendance_dashboard.html',
                               total_present=summary['total_present'],
                               total_absent=summary['total_absent'],
                               total_employees=summary['total_employees'],
                               records=summary['records'])

    @attendance_bp.route('/attendance/capture/<int:emp_id>', methods=['GET'])
    def attendance_capture_page(emp_id):
        if 'loggedin' not in session:
            return redirect(url_for('auth.login'))
        return render_template('attendance_capture.html', emp_id=emp_id)

    @attendance_bp.route('/attendance/capture/<int:emp_id>', methods=['POST'])
    def capture_attendance(emp_id):
        data = request.get_json()
        image_data = data.get('photo_data')

        if not image_data:
            return jsonify({'status': 'error', 'message': 'No image data received.'}), 400

        try:
            header, encoded = image_data.split(",", 1)
            binary_data = base64.b64decode(encoded)

            folder_path = os.path.join(current_app.static_folder, 'attendance_photos')
            os.makedirs(folder_path, exist_ok=True)

            filename = f"{emp_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}.png"
            file_path = os.path.join(folder_path, filename)

            with open(file_path, 'wb') as f:
                f.write(binary_data)

            # Mark attendance with photo
            att_model.mark_attendance(emp_id, photo_filename=filename)

            return jsonify({'status': 'success', 'message': 'Attendance marked successfully with photo.'})

        except Exception as e:
            print(f"[ERROR] Capture attendance: {e}")
            return jsonify({'status': 'error', 'message': f'Error saving photo: {str(e)}'}), 500

    app.register_blueprint(attendance_bp)
