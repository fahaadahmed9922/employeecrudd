# /routes/chatbot_routes.py

from flask import Blueprint, render_template, request, jsonify
from models.employee_model import EmployeeModel
from models.attendance_model import AttendanceModel

chatbot_bp = Blueprint('chatbot', __name__)

def init_chatbot_routes(app, mysql):
    emp_model = EmployeeModel(mysql, app.config['UPLOAD_FOLDER'], app.config['QRCODE_FOLDER'])
    att_model = AttendanceModel(mysql)

    @chatbot_bp.route('/chatbot', methods=['GET', 'POST'])
    def chatbot_page():
        if request.method == 'POST':
            data = request.get_json()
            message = data.get('message', '').lower()

            response = "I am sorry, I do not understand that question yet."

            if "how many employees" in message or "total employees" in message:
                count = emp_model.get_employee_count()
                response = f"There are {count} employees in the system."

            elif "how many present" in message or "employees present" in message:
                summary = att_model.get_today_summary()
                response = f"{summary['total_present']} employees are present today."

            elif "male and female" in message or "gender count" in message:
                male_count, female_count = emp_model.get_gender_count()
                response = f"There are {male_count} male and {female_count} female employees."

            return jsonify({'response': response})

        return render_template('chatbot.html')

    app.register_blueprint(chatbot_bp)
