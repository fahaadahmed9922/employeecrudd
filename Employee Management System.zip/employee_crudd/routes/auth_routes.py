# /routes/auth_routes.py

from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from models.user_model import UserModel

auth_bp = Blueprint('auth', __name__)

def init_auth_routes(app, mysql):
    user_model = UserModel(mysql)

    @auth_bp.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            user = user_model.authenticate(username, password)

            if user:
                session['loggedin'] = True
                session['username'] = username
                return redirect(url_for('employee.dashboard'))
            else:
                flash("Invalid username or password", "danger")
                return redirect(url_for('auth.login'))

        return render_template('login.html')

    @auth_bp.route('/logout')
    def logout():
        session.clear()
        return redirect(url_for('auth.login'))

    app.register_blueprint(auth_bp)
