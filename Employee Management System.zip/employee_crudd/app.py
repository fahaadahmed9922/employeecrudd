# app.py

from flask import Flask
from flask_mysqldb import MySQL
import os

import config

from routes.auth_routes import init_auth_routes
from routes.employee_routes import init_employee_routes
from routes.attendance_routes import init_attendance_routes

app = Flask(__name__)
app.secret_key = config.SECRET_KEY

# MySQL Config
app.config['MYSQL_HOST'] = config.MYSQL_HOST
app.config['MYSQL_USER'] = config.MYSQL_USER
app.config['MYSQL_PASSWORD'] = config.MYSQL_PASSWORD
app.config['MYSQL_DB'] = config.MYSQL_DB

# Upload folders
app.config['UPLOAD_FOLDER'] = config.UPLOAD_FOLDER
app.config['QRCODE_FOLDER'] = config.QRCODE_FOLDER
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['QRCODE_FOLDER'], exist_ok=True)

mysql = MySQL(app)

# Register Blueprints
init_auth_routes(app, mysql)
init_employee_routes(app, mysql, app.config['UPLOAD_FOLDER'], app.config['QRCODE_FOLDER'])
init_attendance_routes(app, mysql)

if __name__ == '__main__':
    app.run(debug=True)
