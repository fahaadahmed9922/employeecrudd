# config.py

MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'
MYSQL_PASSWORD = ''
MYSQL_DB = 'employee_db'
SECRET_KEY = 'your_secret_key'
UPLOAD_FOLDER = 'uploads'
QRCODE_FOLDER = 'qrcodes'
