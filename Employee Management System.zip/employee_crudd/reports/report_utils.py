# /reports/report_utils.py

import pandas as pd
from flask import send_file, render_template
from io import BytesIO
from xhtml2pdf import pisa

def export_employees_to_excel(employees):
    df = pd.DataFrame(employees, columns=['ID', 'Name', 'Username', 'Email', 'City'])
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Employees')
        worksheet = writer.sheets['Employees']
        for column_cells in worksheet.columns:
            length = max(len(str(cell.value)) for cell in column_cells)
            worksheet.column_dimensions[column_cells[0].column_letter].width = length + 5
    output.seek(0)
    return send_file(output, download_name='employees.xlsx', as_attachment=True)

def export_attendance_to_excel(attendance_records):
    processed_records = []
    for row in attendance_records:
        employee_name = row[1]
        username = row[2]
        email = row[3]
        city = row[4]
        date_value = row[5].strftime('%Y-%m-%d') if row[5] else ''

        # Instead of using .strftime (which fails if the type is timedelta or str),
        # we will convert to string directly and slice if necessary to keep HH:MM:SS.
        sign_in = str(row[6])[:8] if row[6] else ''
        sign_out = str(row[7])[:8] if row[7] else ''

        processed_records.append([employee_name, username, email, city, date_value, sign_in, sign_out])

    df = pd.DataFrame(processed_records, columns=['Employee Name', 'Username', 'Email', 'City', 'Date', 'Sign In', 'Sign Out'])

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Attendance')
        worksheet = writer.sheets['Attendance']
        for column_cells in worksheet.columns:
            length = max(len(str(cell.value)) for cell in column_cells)
            worksheet.column_dimensions[column_cells[0].column_letter].width = length + 5

    output.seek(0)
    return send_file(output, download_name='attendance.xlsx', as_attachment=True)

def export_to_pdf(template_name, context, pdf_name):
    html = render_template(template_name, **context)
    result = BytesIO()
    pisa_status = pisa.CreatePDF(html, dest=result)
    if pisa_status.err:
        return "PDF generation failed", 500
    result.seek(0)
    return send_file(result, download_name=pdf_name, as_attachment=True)
